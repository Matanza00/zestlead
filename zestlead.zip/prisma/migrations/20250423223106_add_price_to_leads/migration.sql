-- AlterTable
ALTER TABLE `lead` ADD COLUMN `price` DOUBLE NULL;
