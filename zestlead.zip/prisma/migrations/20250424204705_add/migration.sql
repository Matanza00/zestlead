-- AlterTable
ALTER TABLE `discount` ADD COLUMN `stripePromotionId` VARCHAR(191) NULL;
