'use client';
import { useEffect, useState } from 'react';
import UserLayout from '@/components/CombinedNavbar';
import { LucideMessageCircle, LucideSend, LucideHelpCircle } from 'lucide-react';

export default function HelpPage(props) {
  const [faqs, setFaqs] = useState([]);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/user/support/faq')
      .then(res => res.json())
      .then(setFaqs)
      .catch(console.error);

    fetch('/api/user/support/message')
      .then(res => res.json())
      .then(setMessages)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    const res = await fetch('/api/user/support/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: newMessage }),
    });

    const data = await res.json();
    setMessages(prev => [...prev, data]);
    setNewMessage('');
  };

  return (
    <UserLayout>
      <div className="max-w-5xl mx-auto px-4 py-10">
        <div className="bg-white dark:bg-[#10141e] p-6 rounded-xl shadow border border-[#D1D5DC]">
          <div className="flex items-center gap-2 mb-6">
            <LucideHelpCircle className="text-primary w-6 h-6" />
            <h1 className="text-xl font-semibold">Help & Support</h1>
          </div>

          {/* FAQs */}
          <div className="mb-10">
            <h2 className="text-lg font-semibold mb-4 text-gray-800 dark:text-gray-100">FAQs</h2>
            <ul className="space-y-4">
              {faqs.map((faq, index) => (
                <li key={index} className="border-b pb-3">
                  <details className="cursor-pointer">
                    <summary className="font-medium text-gray-700 dark:text-gray-200">{faq.question}</summary>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{faq.answer}</p>
                  </details>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Chat */}
          <div>
            <h2 className="text-lg font-semibold mb-3 text-gray-800 dark:text-gray-100">Chat with Support</h2>
            <div className="space-y-4 max-h-80 overflow-y-auto border rounded p-4 bg-gray-50 dark:bg-[#141b29]">
              {loading ? (
                <p>Loading messages...</p>
              ) : messages.length === 0 ? (
                <p className="text-gray-500">No messages yet.</p>
              ) : (
                messages.map((msg, i) => (
                  <div key={i} className="text-sm">
                    <div className="mb-1 font-semibold text-gray-700">{msg.role === 'admin' ? 'Support' : 'You'}:</div>
                    <div className="bg-white dark:bg-[#1d263b] p-2 rounded text-gray-800 dark:text-gray-100">
                      {msg.text}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      {new Date(msg.timestamp).toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 flex items-center gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                placeholder="Ask a question..."
                className="w-full border rounded px-4 py-2 text-sm"
              />
              <button
                onClick={sendMessage}
                className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/80 flex items-center gap-1"
              >
                <LucideSend className="w-4 h-4" />
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
    </UserLayout>
  );
}
